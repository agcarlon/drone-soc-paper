"""
Paper experiment: §5.5 — wind-aligned vs. free-φ HJB computational savings.

Compares single-drone planning with wind_aligned=True (φ fixed to α, 5-D HJB)
against wind_aligned=False (φ free, 6-D HJB).  Localisation accuracy and
energy are expected to be statistically indistinguishable; the 6-D grid
requires ~num_belief_discr times more HJB points and proportionally more compute.

Usage:
    python3 experiments/exp_wind_aligned_comparison.py --num-seeds 100

Output (results/wind_aligned_comparison/):
  wind_aligned_comparison.csv  — one row per (seed, wind_aligned flag)

Run plots:
  python3 plotting/plot_wind_aligned_comparison.py
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
import types
from typing import Any, Dict, List

import numpy as np

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if ROOT not in sys.path:
    sys.path.insert(0, ROOT)

from _drone_soc_internal import construct_hjb_grid_axes  # noqa: E402
from drone_soc import find_pollutant_source  # noqa: E402
from experiments.exp_pairwise_showcase import (  # noqa: E402
    RuntimeOverrides,
    _build_case,
    _sample_scenario,
)
from infinite_horizon import InfiniteHorizonSingleDronePlanner  # noqa: E402
from experiments.fixed_point_diagnostics import fixed_point_metrics  # noqa: E402

DEFAULT_OUT_DIR = os.path.join(ROOT, "results", "wind_aligned_comparison")
DEFAULT_VARIANT = "prior_tuned"
DEFAULT_DISCOUNT = 0.3


def _runtime(num_belief_discr: int = 3) -> RuntimeOverrides:
    return RuntimeOverrides(
        t_end=600.0,
        dt_meas=30.0,
        dx=60.0,
        dx_secondary=120.0,
        num_belief_discr=num_belief_discr,
        fp_max_iter=12,
    )


def _make_timed_planner(wind_aligned: bool, fp_solver) -> InfiniteHorizonSingleDronePlanner:
    """Wrap a planner to record wall-clock time of each plan() call in .planning_times."""
    planner = InfiniteHorizonSingleDronePlanner(
        wind_aligned=wind_aligned, fp_solver=fp_solver
    )
    planner.planning_times: List[float] = []
    original_plan = planner.plan

    def _timed_plan(t_now, par, problem, s):
        t0 = time.perf_counter()
        result = original_plan(t_now, par, problem, s)
        planner.planning_times.append(time.perf_counter() - t0)
        return result

    planner.plan = types.MethodType(
        lambda self, t_now, par, problem, s: _timed_plan(t_now, par, problem, s),
        planner,
    )
    return planner


def _run_seed(
    seed: int,
    *,
    wind_aligned: bool,
    variant: str,
    discount: float,
    runtime: RuntimeOverrides,
    output_dir: str,
) -> Dict[str, Any]:
    scenario = _sample_scenario(seed, variant)
    par, problem, state, fp_solver = _build_case(
        scenario=scenario,
        discount=discount,
        out_dir=output_dir,
        variant=variant,
        runtime=runtime,
    )

    planner = _make_timed_planner(wind_aligned=wind_aligned, fp_solver=fp_solver)

    grid_axes = construct_hjb_grid_axes(par, problem, state, num_drones=1, wind_aligned=wind_aligned)
    grid_size = int(np.prod([len(a) for a in grid_axes]))

    traj_arr, log = find_pollutant_source(par, problem, state, planner=planner)

    theta_true = np.asarray(problem.pollutant.source, dtype=float)
    mu_final = np.asarray(log["beliefs"][-1].mu, dtype=float)
    dist_final = float(np.linalg.norm(mu_final - theta_true))

    energy = float(log.get("energy_total", 0.0))
    stopped = log.get("stop_reason", "").startswith("confidence_criterion_met")

    planning_times = getattr(planner, "planning_times", [])
    first_plan_time = planning_times[0] if planning_times else float("nan")
    total_plan_time = sum(planning_times)

    row = dict(
        seed=seed,
        wind_aligned=wind_aligned,
        dist_final=dist_final,
        energy=energy,
        stopped=stopped,
        first_plan_time=first_plan_time,
        total_plan_time=total_plan_time,
        num_plan_calls=len(planning_times),
        grid_size=grid_size,
        hjb_dims=len(grid_axes),
    )
    row.update(fixed_point_metrics(fp_solver, output_dir))
    return row


def _summarise(rows: List[Dict[str, Any]], label: str) -> None:
    n = len(rows)
    stop_rate = np.mean([r["stopped"] for r in rows])
    dists = [r["dist_final"] for r in rows]
    energies = [r["energy"] for r in rows]
    t1s = [r["first_plan_time"] for r in rows]
    gs = rows[0]["grid_size"] if rows else "?"
    dims = rows[0]["hjb_dims"] if rows else "?"
    print(f"\n{label}  (n={n})")
    print(f"  HJB dims / grid size : {dims}-D  /  {gs:,} points")
    print(f"  Stop rate            : {stop_rate:.0%}")
    print(f"  Dist to source [m]   : median={np.median(dists):.1f}  "
          f"q25={np.quantile(dists,0.25):.1f}  q75={np.quantile(dists,0.75):.1f}")
    print(f"  Energy [m]           : median={np.median(energies):.0f}  "
          f"q25={np.quantile(energies,0.25):.0f}  q75={np.quantile(energies,0.75):.0f}")
    print(f"  First plan time [s]  : median={np.median(t1s):.2f}  "
          f"q25={np.quantile(t1s,0.25):.2f}  q75={np.quantile(t1s,0.75):.2f}")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--num-seeds", type=int, default=100)
    parser.add_argument("--variant", type=str, default=DEFAULT_VARIANT)
    parser.add_argument("--discount", type=float, default=DEFAULT_DISCOUNT)
    parser.add_argument("--num-belief-discr", type=int, default=3,
                        help="Grid points per belief axis. 6-D grid has this factor more points.")
    parser.add_argument("--out-dir", type=str, default=DEFAULT_OUT_DIR)
    args = parser.parse_args()

    os.makedirs(args.out_dir, exist_ok=True)
    runtime = _runtime(num_belief_discr=args.num_belief_discr)

    rows_wa: List[Dict[str, Any]] = []
    rows_nwa: List[Dict[str, Any]] = []

    for seed in range(args.num_seeds):
        print(f"Seed {seed:3d}  wind_aligned=True  ...", end="  ", flush=True)
        r_wa = _run_seed(
            seed, wind_aligned=True,
            variant=args.variant, discount=args.discount, runtime=runtime,
            output_dir=os.path.join(args.out_dir, f"seed_{seed:03d}", "wind_aligned"),
        )
        rows_wa.append(r_wa)
        print(f"dist={r_wa['dist_final']:.0f}m  E={r_wa['energy']:.0f}m  "
              f"t1={r_wa['first_plan_time']:.2f}s  "
              f"stopped={'yes' if r_wa['stopped'] else 'no'}")

        print(f"Seed {seed:3d}  wind_aligned=False ...", end="  ", flush=True)
        r_nwa = _run_seed(
            seed, wind_aligned=False,
            variant=args.variant, discount=args.discount, runtime=runtime,
            output_dir=os.path.join(args.out_dir, f"seed_{seed:03d}", "full_angle"),
        )
        rows_nwa.append(r_nwa)
        print(f"dist={r_nwa['dist_final']:.0f}m  E={r_nwa['energy']:.0f}m  "
              f"t1={r_nwa['first_plan_time']:.2f}s  "
              f"stopped={'yes' if r_nwa['stopped'] else 'no'}")

    # Save CSV
    csv_path = os.path.join(args.out_dir, "wind_aligned_comparison.csv")
    all_rows = rows_wa + rows_nwa
    with open(csv_path, "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=list(all_rows[0].keys()))
        writer.writeheader()
        writer.writerows(all_rows)
    print(f"\nSaved CSV → {csv_path}")

    _summarise(rows_wa, "wind_aligned=True  (5-D HJB)")
    _summarise(rows_nwa, "wind_aligned=False (6-D HJB)")

    t_wa = np.median([r["first_plan_time"] for r in rows_wa])
    t_nwa = np.median([r["first_plan_time"] for r in rows_nwa])
    print(f"\nPlan-time speedup (wind-align vs no-align): {t_nwa/t_wa:.2f}×  "
          f"(expected ~{args.num_belief_discr}× from grid size)")

    print("\nRun  python3 plotting/plot_wind_aligned_comparison.py  to generate the figure.")


if __name__ == "__main__":
    main()
